import { useState, useEffect } from "react";
import NotificationToast from "./components/NotificationToast";
import AssessmentQuiz from "./components/AssessmentQuiz";
import FaqSection from "./components/FaqSection";
import CheckoutModal from "./components/CheckoutModal";

// Tokenized sub-sections
import UrgencyBanner from "./components/UrgencyBanner";
import HeroHeader from "./components/HeroHeader";
import StorySection from "./components/StorySection";
import UnlockSection from "./components/UnlockSection";
import DeepPainSection from "./components/DeepPainSection";
import ValueProposalSection from "./components/ValueProposalSection";
import ExpectationsSection from "./components/ExpectationsSection";
import BonusesSection from "./components/BonusesSection";
import CostAnalysisSection from "./components/CostAnalysisSection";
import BillReceiptSection from "./components/BillReceiptSection";
import FinalSummarySection from "./components/FinalSummarySection";
import Footer from "./components/Footer";

export default function App() {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  // Scroll tracking for progress indicator progress line
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress(window.scrollY / totalScroll);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const openCheckout = () => {
    setIsCheckoutOpen(true);
    // Explicitly focus user on checkout form
    setTimeout(() => {
      const formEl = document.getElementById("checkout-name");
      if (formEl) formEl.focus();
    }, 300);
  };

  return (
    <div className="bg-[#0a0a0a] min-h-screen font-sans text-[#d4d4d4] selection:bg-brand-red/10 selection:text-brand-red relative antialiased leading-relaxed">
      {/* Scroll Progress Line */}
      <div 
        className="fixed top-0 left-0 h-1 bg-brand-red z-100 transition-all duration-75"
        style={{ width: `${scrollProgress * 100}%` }}
      />

      {/* Persistent Sticky Top Urgency Banner */}
      <UrgencyBanner onOpenCheckout={openCheckout} />

      {/* Main Container */}
      <main className="relative overflow-x-hidden">
        
        {/* HERO HEADER SECTION */}
        <HeroHeader />

        {/* HERO STORY & PAIN STATEMENTS */}
        <StorySection onOpenCheckout={openCheckout} />

        {/* SECTION: ¿QUÉ DESBLOQUEARÁS? */}
        <UnlockSection />

        {/* TESTIMONIO / POETIC STATEMENT SECTION: LO QUE MÁS TE DUELE NO ES LA AUSENCIA */}
        <DeepPainSection />

        {/* INTERACTIVE ASSESSMENT SECTION: ¿PARA QUIÉN ES ESTO? */}
        <section className="py-20 md:py-28 bg-[#0a0a0a] border-b border-white/5">
          <div className="max-w-4xl mx-auto px-4 space-y-12">
            <div className="text-center space-y-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm text-[10px] font-bold bg-white/5 border border-white/10 text-zinc-300 uppercase tracking-wider">
                Requisitos de Admisión
              </span>
              <h2 className="font-serif text-4.5xl md:text-6xl font-black tracking-tight text-white uppercase">
                ¿PARA QUIÉN ES ESTO?
              </h2>
              <p className="text-zinc-400 text-xs md:text-sm max-w-xl mx-auto font-sans">
                Este programa es para ti si te identificas con uno o más de los siguientes desafíos emocionales activos:
              </p>
            </div>

            {/* Embed our high-quality Interactive Quiz Widget */}
            <AssessmentQuiz onOpenCheckout={openCheckout} />
          </div>
        </section>

        {/* BLOCK: LO QUE REALMENTE ESTÁS COMPRANDO */}
        <ValueProposalSection />

        {/* SECTION: ¿QUÉ PUEDES ESPERAR? */}
        <ExpectationsSection />

        {/* SECTION: BONOS EXCLUSIVOS */}
        <BonusesSection />

        {/* SECTION: HAZ CUENTAS... */}
        <CostAnalysisSection />

        {/* VALUE WRAPPER / RECEIPT BILL: RESUMEN DE LO QUE TE LLEVAS */}
        <BillReceiptSection onOpenCheckout={openCheckout} />

        {/* SECTION: PREGUNTAS FRECUENTES */}
        <section className="py-20 md:py-28 bg-[#0a0a0a] border-b border-white/10">
          <div className="max-w-4xl mx-auto px-4 space-y-12">
            <div className="text-center space-y-4">
              <span className="font-mono text-xs font-bold text-zinc-500 uppercase tracking-widest block">RESOLUCIÓN DE DUDAS</span>
              <h2 className="font-serif text-4.5xl md:text-6xl font-black text-white uppercase tracking-tight">
                PREGUNTAS FRECUENTES
              </h2>
            </div>

            <FaqSection />
          </div>
        </section>

        {/* SECTION: RESUMEN FINAL */}
        <FinalSummarySection onOpenCheckout={openCheckout} />

      </main>

      {/* FOOTER */}
      <Footer />

      {/* Real-time Dynamic Social Activity Notifications */}
      <NotificationToast />

      {/* STRIPE PAYMENTS MODAL SIMULATOR */}
      <CheckoutModal isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} />
    </div>
  );
}
