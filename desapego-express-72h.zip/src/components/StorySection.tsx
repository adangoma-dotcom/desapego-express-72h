import { ArrowRight, ShieldCheck } from "lucide-react";

interface StorySectionProps {
  onOpenCheckout: () => void;
}

export default function StorySection({ onOpenCheckout }: StorySectionProps) {
  return (
    <section className="py-16 md:py-24 max-w-3xl mx-auto px-4 relative">
      <div className="space-y-6 text-[15px] md:text-lg text-zinc-300 font-sans tracking-normal leading-relaxed">
        <span className="font-mono text-xs uppercase tracking-widest text-zinc-500 block mb-2">EL BUCLE DE LA OBSESIÓN...</span>
        <p className="font-semibold text-white text-lg md:text-xl">
          Te despiertas y ahí está.
        </p>
        <div className="pl-4 border-l border-brand-red/50 space-y-2 py-1 text-white font-medium">
          <p>Su nombre.</p>
          <p>Su recuerdo.</p>
          <p>La conversación que nunca ocurrió.</p>
          <p>La explicación que nunca llegó.</p>
        </div>
        
        <p>
          Intentas concentrarte en tu trabajo, salir con amigos o seguir adelante, pero tu mente siempre encuentra el camino de regreso al mismo lugar.
        </p>
        
        <p className="text-zinc-200 font-semibold bg-white/5 p-6 rounded-sm border border-white/10 shadow-xl relative">
          <span className="text-xs uppercase tracking-wider block text-brand-red mb-1 font-bold">La paradoja invisible:</span>
          Y lo peor no es la tristeza. <br />
          <strong className="text-brand-red font-bold text-xl md:text-2xl block mt-1">Es la esperanza.</strong>
        </p>

        <p>
          Esa esperanza silenciosa que te hace revisar sus redes, interpretar señales y convencerte de que quizá todavía existe una posibilidad.
        </p>
        <p>
          Mientras tanto, tu vida queda en pausa. Tus metas se detienen. Tu energía desaparece.
        </p>
        <p className="font-medium text-white">
          Y sin darte cuenta, empiezas a dedicar más tiempo a alguien que ya no está que a construir la persona que quieres ser.
        </p>

        {/* Visual Divider Card */}
        <div className="my-12 bg-[#0d0d0d] text-white p-8 md:p-10 border border-white/10 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-48 h-48 bg-brand-red opacity-10 rounded-full blur-3xl" />
          <p className="font-mono text-zinc-400 text-xs font-semibold tracking-wider uppercase mb-2">La incomodidad de la verdad</p>
          <h3 className="font-serif text-2xl md:text-3.5xl font-bold tracking-tight mb-4 leading-tight">
            No sufres solo porque perdiste a alguien. Sufres porque también perdiste la versión de ti que existía dentro de esa relación.
          </h3>
          <p className="text-zinc-300 text-sm md:text-[15px] leading-relaxed">
            Por eso algunas rupturas duelen tanto. No rompen únicamente un vínculo. Rompen rutinas, sueños, planes y una identidad que construiste durante años. Y mientras sigas intentando recuperar el pasado, seguirás alejándote de tu futuro.
          </p>
        </div>

        <p className="text-zinc-300">
          Por eso existe <strong className="font-bold text-white">Desapego Express 72H</strong>.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 my-2">
          <div className="p-5 rounded-sm border border-white/10 bg-white/5 text-xs md:text-sm">
            <span className="text-brand-red font-bold block mb-1">Lo que NO es:</span>
            No para borrar recuerdos. No para fingir que nunca amaste.
          </div>
          <div className="p-5 rounded-sm border border-brand-red/30 bg-[#0d0d0d] text-white shadow-md text-xs md:text-sm">
            <span className="text-amber-400 font-bold block mb-1">Lo que SÍ es:</span>
            Para ayudarte a recuperar el control de tu mente, romper la dependencia emocional y volver a elegirte a ti.
          </div>
        </div>

        <blockquote className="border-l-2 border-brand-red pl-5 py-2 font-serif text-lg md:text-xl text-white italic font-semibold my-8 bg-brand-red/5 pr-4 rounded-r-sm">
          "Porque superar una ruptura no significa olvidar a alguien. Significa dejar de abandonarte a ti mismo."
        </blockquote>

        {/* Dynamic Interactive Call to Action */}
        <div className="pt-6 text-center">
          <button
            onClick={onOpenCheckout}
            className="w-full sm:w-auto px-8 py-5 rounded-sm bg-brand-red text-black hover:bg-white text-xs md:text-sm font-black flex items-center justify-center gap-3 shadow-xl shadow-brand-red/20 transition-all duration-300 hover:scale-[1.03] cursor-pointer group uppercase tracking-widest"
          >
            <span>QUIERO RECUPERAR MI PAZ AHORA</span>
            <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
          </button>
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-zinc-500 mt-3.5 font-mono">
            <ShieldCheck size={13} className="text-emerald-500" />
            <span>PAGO PROCESADO CON ENCRIPTACIÓN SEGURA DE 256 BITS</span>
          </div>
        </div>
      </div>
    </section>
  );
}
