import { CheckCircle2, ShieldCheck } from "lucide-react";

interface BillReceiptProps {
  onOpenCheckout: () => void;
}

export default function BillReceiptSection({ onOpenCheckout }: BillReceiptProps) {
  return (
    <section className="py-20 md:py-28 bg-[#0d0d0d] border-b border-white/10">
      <div className="max-w-2xl mx-auto px-4 relative">
        <div className="bg-black/40 border border-white/10 rounded-sm shadow-2xl p-6 md:p-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-red opacity-5 rounded-full blur-2xl" />
          
          <div className="text-center space-y-2 pb-6 border-b border-white/10">
            <span className="font-mono text-[10px] font-bold text-brand-red uppercase tracking-widest block">TU FACTURA DE ACCESO</span>
            <h2 className="font-serif text-3.5xl md:text-4.5xl font-black text-white uppercase">
              RESUMEN DE LO QUE TE LLEVAS
            </h2>
          </div>

          {/* Items checklist table */}
          <div className="py-6 space-y-3.5 text-xs text-zinc-300">
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white">
                <CheckCircle2 size={15} className="text-brand-red" />
                ✓ Desapego Express 72H
              </span>
              <span className="font-mono text-zinc-500"><del>$97.00</del></span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white">
                <CheckCircle2 size={15} className="text-amber-500" />
                ✓ Protocolo de Corte Mental 72H
              </span>
              <span className="font-mono text-emerald-400 font-bold">INCLUIDO</span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white">
                <CheckCircle2 size={15} className="text-violet-500" />
                ✓ Método Anti-Idealización
              </span>
              <span className="font-mono text-emerald-400 font-bold">INCLUIDO</span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white">
                <CheckCircle2 size={15} className="text-zinc-300" />
                ✓ Sistema de Recuperación de Identidad
              </span>
              <span className="font-mono text-emerald-400 font-bold">INCLUIDO</span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white">
                <CheckCircle2 size={15} className="text-pink-600" />
                ✓ Plan de Emergencia Anti-Recaídas
              </span>
              <span className="font-mono text-emerald-400 font-bold">INCLUIDO</span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white font-light">
                <CheckCircle2 size={15} className="text-brand-red" />
                ✓ Ritual de Liberación Emocional (Bono #1)
              </span>
              <span className="font-mono text-emerald-400 font-bold">BONO GRATIS</span>
            </div>
            <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
              <span className="flex items-center gap-2.5 font-semibold text-white font-light">
                <CheckCircle2 size={15} className="text-brand-red" />
                ✓ Guión Anti-Recaídas (Bono #2)
              </span>
              <span className="font-mono text-emerald-400 font-bold">BONO GRATIS</span>
            </div>
            <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
              <span className="flex items-center gap-2.5 font-semibold text-white font-light">
                <CheckCircle2 size={15} className="text-brand-red" />
                ✓ Test de Realidad (Bono #3)
              </span>
              <span className="font-mono text-emerald-400 font-bold">BONO GRATIS</span>
            </div>
          </div>

          {/* Secure checkout block */}
          <div className="pt-6 border-t border-white/10 text-center space-y-4">
            <div className="flex justify-between items-center bg-white/5 p-4 rounded-sm border border-white/10">
              <span className="text-sm font-bold text-white uppercase tracking-wide">PRECIO ESPECIAL CON LA OFERTA</span>
              <span className="text-2xl md:text-3.5xl font-mono font-black text-brand-red animate-pulse">$27.00 USD</span>
            </div>

            <button
              onClick={onOpenCheckout}
              className="w-full py-4.5 rounded-sm bg-brand-red text-white hover:bg-[#b02f2f] text-sm font-black flex items-center justify-center gap-2.5 shadow-xl shadow-brand-red/25 transition-all duration-300 hover:scale-[1.02] cursor-pointer"
            >
              <ShieldCheck size={16} />
              QUIERO RECUPERAR MI PAZ AHORA
            </button>

            <p className="text-[10px] text-zinc-400 block uppercase tracking-widest font-bold">
              SÓLO $27 USD • ACCESO COMPLETO INMEDIATO Y DE POR VIDA
            </p>
          </div>

          {/* Guarantee badge */}
          <div className="mt-8 pt-6 border-t border-white/10 flex items-center gap-4 text-left">
            <div className="flex-shrink-0 w-12 h-12 rounded-full border border-brand-red/20 bg-brand-red/5 flex items-center justify-center text-brand-red font-serif text-lg font-bold">
              7D
            </div>
            <div className="text-xs">
              <strong className="text-white block font-bold">Garantía Incondicional de Devolución de 7 Días</strong>
              <p className="text-zinc-400 font-normal leading-relaxed text-[11px]">
                Si en 7 días aplicando el protocolo sientes que tu apego mental y tu dolor rumiante no han disminuido radicalmente, solicítanos un reembolso total sin dar explicaciones. Tu paz es lo primero.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
