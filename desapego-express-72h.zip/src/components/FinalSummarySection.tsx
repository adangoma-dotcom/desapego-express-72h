import { ArrowRight } from "lucide-react";

interface FinalSummarySectionProps {
  onOpenCheckout: () => void;
}

export default function FinalSummarySection({ onOpenCheckout }: FinalSummarySectionProps) {
  return (
    <section className="py-20 md:py-28 bg-[#0d0d0d] text-white relative border-b border-white/5">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:14px_24px]" />
      
      <div className="max-w-3xl mx-auto px-4 text-center relative z-10 space-y-8">
        <span className="font-mono text-xs font-bold text-[#d33c3c] bg-white/5 border border-white/10 px-3.5 py-1 rounded-sm uppercase tracking-widest inline-block">
          Reflexión de Cierre
        </span>
        
        <h2 className="font-serif text-4.5xl md:text-6.5xl font-black text-white uppercase tracking-tight leading-none">
          RESUMEN FINAL
        </h2>

        <div className="mx-auto w-10 h-[1px] bg-zinc-700" />

        <div className="space-y-5 text-sm md:text-lg text-zinc-300 font-sans leading-relaxed text-justify sm:text-center max-w-2xl mx-auto">
          <p>
            La mayoría de las personas espera que el tiempo haga el trabajo. Pero el tiempo, por sí solo, no cambia nada. Lo que cambia las cosas es decidir que ya no quieres seguir viviendo atrapado en una historia que terminó.
          </p>
          <p className="font-semibold text-white">
            No se trata de olvidar a alguien. No se trata de dejar de amar.
          </p>
          <p className="font-serif text-xl md:text-2xl text-brand-red italic font-medium leading-normal">
            Se trata de recuperar tu paz, tu energía y la capacidad de volver a construir una vida que no dependa de otra persona.
          </p>
          <p className="font-bold text-white text-base md:text-lg">
            Porque mientras sigas esperando que algo cambie afuera... Tu verdadera recuperación seguirá esperando adentro.
          </p>
        </div>

        <div className="pt-6">
          <button
            onClick={onOpenCheckout}
            className="w-full sm:w-auto px-10 py-5 rounded-sm bg-brand-red text-white hover:bg-[#b02f2f] text-sm md:text-base font-extrabold flex items-center justify-center gap-2.5 shadow-2xl shadow-brand-red/30 transition-all duration-300 hover:scale-[1.03] cursor-pointer group"
          >
            <span>EMPEZAR MI TRANSFORMACIÓN AHORA</span>
            <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  );
}
