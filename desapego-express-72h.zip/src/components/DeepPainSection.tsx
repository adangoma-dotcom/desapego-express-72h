export default function DeepPainSection() {
  return (
    <section className="py-20 md:py-28 bg-[#0d0d0d] border-y border-white/10">
      <div className="max-w-3xl mx-auto px-4 space-y-8 text-[15px] md:text-lg text-zinc-300 leading-relaxed font-sans">
        <div className="space-y-3 text-center md:text-left">
          <span className="font-mono text-xs font-bold text-zinc-500 block uppercase tracking-widest">REALIDAD CIENTÍFICA</span>
          <h2 className="font-serif text-3.5xl md:text-5.5xl text-white font-black tracking-tight leading-tight uppercase">
            LO QUE MÁS TE DUELE NO ES LA AUSENCIA
          </h2>
          <p className="font-serif text-xl md:text-2xl text-brand-red italic leading-relaxed">
            Es sentir que perdiste el control de tu propia mente.
          </p>
        </div>

        <div className="w-16 h-[1px] bg-brand-red my-4 text-center md:text-left mx-auto md:mx-0" />

        <p>
          Hay personas que terminan una relación y siguen adelante. Y hay otras que siguen teniendo conversaciones imaginarias seis meses después.
        </p>
        
        <p className="font-semibold text-white bg-white/5 p-5 rounded-sm border border-white/10 inline-block w-full">
          No porque sean más débiles. <br />
          No porque amen más. <br />
          <strong className="text-brand-red">Sino porque nadie les enseñó qué hacer con el vacío que deja una ruptura.</strong>
        </p>

        <p>
          Entonces intentan distraerse. Trabajan más. Salen más. Se mantienen ocupados.
        </p>
        <p className="pl-4 border-l-2 border-white/10 italic text-zinc-400 space-y-2 py-0.5 text-sm md:text-base">
          "Pero cada noche vuelven al mismo lugar. A los recuerdos. A las preguntas. A las posibilidades que ya no existen."
        </p>

        <div className="bg-[#0a0a0a] text-white p-6 md:p-8 border border-white/10 relative overflow-hidden shadow-xl my-10 rounded-sm">
          <span className="text-[10px] font-bold tracking-widest text-[#d33c3c] block mb-2 font-mono uppercase">El factor determinante</span>
          <p className="font-serif text-xl md:text-3xl font-bold tracking-tight mb-4 leading-normal">
            El problema es que el tiempo no cura automáticamente. <br />
            <span className="text-brand-red underline decoration-1 underline-offset-4">Lo que cura es lo que haces durante ese tiempo.</span>
          </p>
          <p className="text-zinc-400 text-xs md:text-sm leading-relaxed font-normal">
            Porque puedes pasar un año esperando sentirte mejor. O puedes empezar hoy mismo a recuperar el control emotional que entregaste sin darte cuenta.
          </p>
        </div>

        <p>
          Desapego Express 72H fue creado para eso. Para ayudarte a salir del ciclo de obsesión, nostalgia y esperanza que mantiene a miles de personas atrapadas mucho después de que la relación terminó.
        </p>

        <p className="font-serif text-xl text-white font-bold text-center md:text-left">
          No necesitas olvidar tu historia. <span className="text-brand-red italic underline font-normal block md:inline font-serif font-semibold text-xl">Necesitas dejar de vivir dentro de ella.</span>
        </p>
      </div>
    </section>
  );
}
