import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ShieldCheck, Flame } from "lucide-react";

interface Notification {
  id: number;
  name: string;
  location: string;
  timeText: string;
}

const mockActivity: Omit<Notification, "id">[] = [
  { name: "Sofía M.", location: "Buenos Aires", timeText: "acaba de iniciar su protocolo 72H" },
  { name: "Alejandro G.", location: "Madrid", timeText: "acaba de unirse y descargar los bonos" },
  { name: "María José R.", location: "Bogotá", timeText: "comenzó el Día 1 hace 5 minutos" },
  { name: "Carlos T.", location: "Santiago", timeText: "acaba de desbloquear el Plan Anti-Recaídas" },
  { name: "Daniela L.", location: "Ciudad de México", timeText: "inició la secuencia de corte mental" },
  { name: "Andrés V.", location: "Lima", timeText: "acaba de unirse al programa" }
];

export default function NotificationToast() {
  const [current, setCurrent] = useState<Notification | null>(null);

  useEffect(() => {
    let index = 0;
    
    // Initial delay
    const timer = setTimeout(() => {
      setCurrent({ id: Date.now(), ...mockActivity[index] });
    }, 4000);

    const interval = setInterval(() => {
      index = (index + 1) % mockActivity.length;
      setCurrent(null);
      
      const revealTimeout = setTimeout(() => {
        setCurrent({ id: Date.now(), ...mockActivity[index] });
      }, 500);

      return () => clearTimeout(revealTimeout);
    }, 12000);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="fixed bottom-4 left-4 z-55 max-w-sm w-[90vw] pointer-events-none md:w-auto">
      <AnimatePresence>
        {current && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="flex items-center gap-3 bg-brand-charcoal text-white/90 p-3.5 rounded-xl border border-white/5 shadow-2xl backdrop-blur-md pointer-events-auto"
          >
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-red/20 border border-brand-red/30 flex items-center justify-center text-brand-red">
              <Flame size={15} className="animate-pulse" />
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-white truncate flex items-center gap-1.5">
                {current.name} 
                <span className="text-white/40 font-normal text-[10px] bg-white/5 px-1.5 py-0.5 rounded-sm uppercase tracking-wider">
                  {current.location}
                </span>
              </p>
              <p className="text-[11px] text-white/70 line-clamp-1">{current.timeText}</p>
            </div>

            <div className="flex-shrink-0 text-[10px] text-emerald-400 font-medium flex items-center gap-1 pl-2 border-l border-white/10">
              <ShieldCheck size={11} /> Active
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
