import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, AlertCircle, HeartCrack, ChevronRight, RefreshCw, Sparkles } from "lucide-react";

const symptoms = [
  {
    id: "s1",
    label: "Sigues pensando en tu ex varias veces al día",
    description: "Tu cerebro genera constantes picos de dopamina buscando el recuerdo de la otra persona, lo que crea un desgaste de energía continuo."
  },
  {
    id: "s2",
    label: "Sientes que una parte de tu vida se quedó atrapada en esa relación",
    description: "Tus rutinas, expectativas y confianza parecen congeladas en el pasado, imposibilitando que conectes con tu presente."
  },
  {
    id: "s3",
    label: "Has intentado avanzar, pero terminas volviendo emocionalmente al mismo punto",
    description: "El clásico ciclo de 'recaída invisible'. Tomas distancia momentánea pero un recuerdo, canción o disparador te regresa a cero."
  },
  {
    id: "s4",
    label: "Te cuesta aceptar que la relación terminó",
    description: "Mantienes viva la fantasía o la esperanza de una explicación ideal que nunca llegará, lo que prolonga la parálisis indefinidamente."
  },
  {
    id: "s5",
    label: "Quieres recuperar tu tranquilidad sin depender de que la otra persona cambie o regrese",
    description: "Estás listo o lista para dejar de ser víctima de las circunstancias ajenas y recuperar el control absoluto de tus emociones."
  }
];

export default function AssessmentQuiz({ onOpenCheckout }: { onOpenCheckout: () => void }) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showResult, setShowResult] = useState(false);

  const toggleSymptom = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const currentLevel = selectedIds.length;

  const getDiagnosis = () => {
    if (currentLevel === 0) {
      return {
        title: "Apego Moderado o Etapa Inicial",
        percentage: "20%",
        level: "Bajo - Preventivo",
        color: "text-emerald-400 bg-emerald-950/40 border-emerald-500/20",
        barColor: "bg-emerald-500",
        desc: "Estás en una fase de introspección inicial. Aunque sufres la ruptura, tienes cierta claridad. Entrar ahora al programa te ahorrará meses de estancamiento involuntario y evitará que caigas en etapas más profundas de obsesión."
      };
    } else if (currentLevel <= 2) {
      return {
        title: "Apego Residual Activo",
        percentage: "55%",
        level: "Medio - Alerta Emocional",
        color: "text-amber-400 bg-amber-950/40 border-amber-500/20",
        barColor: "bg-amber-500",
        desc: "Tu mente lucha activamente entre olvidar y mantener viva la esperanza. Tienes recaídas constantes al revisar redes o idear conversaciones imaginarias. El Método Anti-Idealización y el Plan Anti-Recaídas de 72H cortará este ciclo de raíz."
      };
    } else {
      return {
        title: "Dependencia Psicológica Profunda",
        percentage: "85%+",
        level: "Fase Crítica - Urgencia de Reset",
        color: "text-orange-400 bg-orange-950/40 border-orange-500/20",
        barColor: "bg-brand-red",
        desc: "Sufres de sobre-análisis crónico y parálisis existencial. Has entregado involuntariamente el control de tu paz mental a su ausencia. Cada hora de espera debilita tu autoestima. El Protocolo de Corte Mental es imperativo para ti en las próximas 72 horas."
      };
    }
  };

  const diagnosis = getDiagnosis();

  return (
    <div id="assessment-widget" className="w-full max-w-2xl mx-auto bg-[#0d0d0d] border border-white/10 shadow-3xl rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="bg-black/50 text-white p-6 md:p-8 relative overflow-hidden border-b border-white/10">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-red opacity-10 rounded-full blur-2xl"></div>
        <div className="relative">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-brand-red/10 border border-brand-red/20 text-brand-red mb-3">
            <HeartCrack size={12} /> Diagnóstico Rápido
          </span>
          <h3 className="font-serif text-3xl font-bold tracking-tight">Evaluación de Apego Activo</h3>
          <p className="text-zinc-400 text-xs mt-1 font-sans">
            Selecciona honestamente las conductas en las que te ves reflejado(a) para calcular tu nivel actual de estancamiento emocional.
          </p>
        </div>
      </div>

      <div className="p-6 md:p-8">
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key="quiz-inputs"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <div className="space-y-3">
                {symptoms.map((symptom, idx) => {
                  const isSelected = selectedIds.includes(symptom.id);
                  return (
                    <button
                      key={symptom.id}
                      onClick={() => toggleSymptom(symptom.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all duration-200 cursor-pointer flex gap-4 ${
                        isSelected
                          ? "bg-white/10 border-brand-red shadow-lg"
                          : "bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10 text-zinc-300"
                      }`}
                    >
                      <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center border transition-colors mt-0.5 ${
                        isSelected 
                          ? "bg-brand-red border-brand-red text-black" 
                          : "border-white/20 bg-black/30 text-transparent"
                      }`}>
                        <Check size={14} strokeWidth={3} />
                      </div>
                      <div>
                        <p className={`font-semibold text-sm ${isSelected ? "text-white" : "text-zinc-200"}`}>
                          {symptom.label}
                        </p>
                        <p className="text-xs text-zinc-400 mt-1 font-normal leading-relaxed">
                          {symptom.description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Progress and Action */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="text-xs text-zinc-400 font-medium">
                  {currentLevel === 0 ? (
                    <span>Ninguno seleccionado. Haz clic arriba para comenzar.</span>
                  ) : (
                    <span>Detectado {currentLevel} de {symptoms.length} síntomas.</span>
                  )}
                </div>

                <button
                  onClick={() => setShowResult(true)}
                  className="w-full sm:w-auto px-6 py-3 rounded bg-white text-black text-xs font-bold hover:bg-brand-red hover:text-black transition-all flex items-center justify-center gap-1.5 self-end cursor-pointer uppercase tracking-wider"
                >
                  Ver Diagnóstico Personalizado
                  <ChevronRight size={14} />
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="quiz-results"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.4 }}
              className="space-y-6"
            >
              {/* Score bar */}
              <div className="bg-black/30 p-6 rounded-xl border border-white/10">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Gravedad del Apego Involuntario</span>
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${diagnosis.color}`}>
                    {diagnosis.level}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1 h-3 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: diagnosis.percentage }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className={`h-full ${diagnosis.barColor}`}
                    ></motion.div>
                  </div>
                  <span className="text-lg font-bold font-mono text-zinc-200">{diagnosis.percentage}</span>
                </div>

                <h4 className="font-serif text-2xl font-bold mt-4 text-white">
                  {diagnosis.title}
                </h4>
                <p className="text-xs text-zinc-300 mt-2 leading-relaxed">
                  {diagnosis.desc}
                </p>
              </div>

              {/* Dynamic Warning Message */}
              <div className="flex gap-3 p-4 rounded-lg bg-brand-red/10 border border-brand-red/20 text-[#ff7826]">
                <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="font-semibold block mb-0.5 text-white">Diagnóstico Clínico del Apego:</strong>
                  La esperanza ilusoria actúa como un virus en tu córtex prefrontal, reviviendo continuamente la relación y drenando tu energía vital para trabajar, superarte o amar. El estancamiento emocional cuesta miles de dólares en productividad y paz mental perdida.
                </div>
              </div>

              {/* Action Stacking */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => {
                    setSelectedIds([]);
                    setShowResult(false);
                  }}
                  className="order-2 sm:order-1 flex-1 py-3.5 px-4 rounded border border-white/10 text-zinc-300 hover:bg-white/5 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RefreshCw size={13} />
                  Reiniciar Test
                </button>

                <button
                  onClick={onOpenCheckout}
                  className="order-1 sm:order-2 flex-[2] py-4 px-6 rounded bg-brand-red text-black hover:bg-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-brand-red/20 transition-all duration-300 hover:scale-[1.02] cursor-pointer uppercase tracking-wider"
                >
                  <Sparkles size={14} className="animate-spin-slow" />
                  Iniciar Mi Protocolo Especial por $27
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
