import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ShieldCheck, CreditCard, Lock, Mail, User, CheckCircle2, Loader2, Sparkles, AlertCircle, FileText, Download } from "lucide-react";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const [step, setStep] = useState<"form" | "loading" | "success">("form");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [card, setCard] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [error, setError] = useState("");
  const [loadingText, setLoadingText] = useState("Encriptando datos de pago...");

  // Reset steps on open
  useEffect(() => {
    if (isOpen) {
      setStep("form");
      setError("");
    }
  }, [isOpen]);

  const handleSimulatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim()) {
      setError("Por favor, introduce tu nombre completo.");
      return;
    }
    if (!email.trim() || !email.includes("@")) {
      setError("Introduce un correo electrónico válido.");
      return;
    }

    // Step to loading simulator
    setStep("loading");

    // Loading sequence
    const texts = [
      "Encriptando datos de pago (SSL 256 bits)...",
      "Asignando tu licencia personal de Desapego Express...",
      "Configurando accesos y enviando pack de Bonos...",
      "Listo. ¡Proceso finalizado con éxito!"
    ];

    let currentTextIndex = 0;
    const interval = setInterval(() => {
      currentTextIndex++;
      if (currentTextIndex < texts.length) {
        setLoadingText(texts[currentTextIndex]);
      } else {
        clearInterval(interval);
        setStep("success");
      }
    }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-100 flex items-center justify-center p-4">
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-stone-950/80 backdrop-blur-md cursor-pointer"
          />

          {/* Checkout Surface */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30 }}
            transition={{ type: "spring", damping: 30, stiffness: 350 }}
            className="relative bg-[#0d0d0d] text-zinc-300 w-full max-w-lg rounded-2xl shadow-3xl overflow-hidden border border-white/10 z-10 flex flex-col"
          >
            {/* Header */}
            <div className="bg-black/60 text-white p-5 flex justify-between items-center relative border-b border-white/10">
              <div>
                <h3 className="font-serif text-xl font-bold tracking-tight">Checkout Seguro</h3>
                <p className="text-zinc-400 text-[11px] font-sans">Estás a un paso de recuperar tu estabilidad</p>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Cerrar modal"
              >
                <X size={18} />
              </button>
            </div>

            {/* Inner Content */}
            <div className="overflow-y-auto max-h-[80vh] p-6 md:p-8">
              {step === "form" && (
                <form onSubmit={handleSimulatePayment} className="space-y-5">
                  {/* Summary of Price Stack */}
                  <div className="bg-black/40 p-4 rounded-xl border border-white/10 divide-y divide-white/5 text-xs text-zinc-300">
                    <div className="pb-2.5 flex justify-between items-center text-zinc-400">
                      <span>Desapego Express 72H (Acceso Vitalicio)</span>
                      <span className="font-mono">$97.00/usd</span>
                    </div>
                    <div className="py-2.5 flex justify-between items-center text-emerald-400 font-medium">
                      <span>3x Bonos de Liberación & Recuperación (Incluidos)</span>
                      <span className="font-mono">GRATIS</span>
                    </div>
                    <div className="pt-2.5 flex justify-between items-center text-white font-bold text-sm">
                      <span className="flex items-center gap-1">
                        Total a pagar 
                        <span className="text-[10px] font-semibold bg-brand-red text-black px-1.5 py-0.5 rounded uppercase tracking-wider">
                          DESCUENTO 87%
                        </span>
                      </span>
                      <span className="text-lg font-mono text-brand-red">$27.00 USD</span>
                    </div>
                  </div>

                  {error && (
                    <div className="bg-brand-red/10 text-brand-red text-xs p-3 rounded-lg flex items-center gap-2 border border-brand-red/25">
                      <AlertCircle size={15} className="flex-shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {/* Form fields */}
                  <div className="space-y-3.5">
                    <div>
                      <label className="block text-[11px] font-bold text-zinc-300 uppercase tracking-wider mb-1" htmlFor="checkout-name">
                        Nombre Completo
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-3.5 h-4.5 w-4.5 text-zinc-500" />
                        <input
                          id="checkout-name"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Tu nombre y apellido"
                          className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs focus:ring-1 focus:ring-brand-red focus:border-brand-red outline-none transition-all placeholder:text-zinc-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-zinc-300 uppercase tracking-wider mb-1" htmlFor="checkout-email">
                        Correo Electrónico de Envío
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3.5 h-4.5 w-4.5 text-zinc-500" />
                        <input
                          id="checkout-email"
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="tucorreo@ejemplo.com"
                          className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs focus:ring-1 focus:ring-brand-red focus:border-brand-red outline-none transition-all placeholder:text-zinc-500"
                        />
                      </div>
                      <span className="text-[10px] text-zinc-400 block mt-1">Este correo será el usuario de acceso inmediato para ver el material.</span>
                    </div>

                    {/* Credit Card Details simulator */}
                    <div>
                      <label className="block text-[11px] font-bold text-zinc-300 uppercase tracking-wider mb-1" htmlFor="checkout-card">
                        Detalles de Compra (Simulada)
                      </label>
                      <div className="space-y-2">
                        <div className="relative">
                          <CreditCard className="absolute left-3 top-3.5 h-4.5 w-4.5 text-zinc-500" />
                          <input
                            id="checkout-card"
                            type="text"
                            maxLength={19}
                            value={card}
                            onChange={(e) => setCard(e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim())}
                            placeholder="4000 1234 5678 9010"
                            className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs focus:ring-1 focus:ring-brand-red focus:border-brand-red outline-none transition-all placeholder:text-zinc-500"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            placeholder="MM / AA"
                            maxLength={5}
                            value={expiry}
                            onChange={(e) => setExpiry(e.target.value)}
                            className="w-full px-3 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs focus:ring-1 focus:ring-brand-red focus:border-brand-red outline-none transition-all text-center placeholder:text-zinc-500"
                          />
                          <input
                            type="password"
                            placeholder="CVC"
                            maxLength={3}
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value)}
                            className="w-full px-3 py-2.5 bg-white/5 border border-white/10 text-white rounded-xl text-xs focus:ring-1 focus:ring-brand-red focus:border-brand-red outline-none transition-all text-center placeholder:text-zinc-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Security Badge */}
                  <div className="flex items-center justify-center gap-2 text-zinc-400 text-[10px] bg-black/40 py-2.5 px-3 rounded-lg border border-white/10">
                    <Lock size={12} className="text-zinc-500" />
                    <span>Encriptación bancaria SSL 256 bits. Pasarela 100% Protegida.</span>
                  </div>

                  {/* Submit checkout button */}
                  <button
                    type="submit"
                    className="w-full py-4 rounded bg-brand-red text-black hover:bg-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-brand-red/20 transition-all duration-300 hover:scale-[1.01] cursor-pointer uppercase tracking-widest"
                  >
                    <ShieldCheck size={14} />
                    Pagar y Confirmar Acceso por $27 USD
                  </button>
                </form>
              )}

              {step === "loading" && (
                <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                  <Loader2 size={40} className="text-brand-red animate-spin" />
                  <p className="text-sm font-semibold text-white">{loadingText}</p>
                  <p className="text-xs text-zinc-400 max-w-xs">No cierres esta pestaña. Estamos encriptando la comunicación con tu gestor de cuenta.</p>
                </div>
              )}

              {step === "success" && (
                <div className="py-4 text-center space-y-6">
                  <div className="mx-auto w-16 h-16 rounded bg-emerald-950/40 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
                    <CheckCircle2 size={32} />
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-serif text-3xl font-bold text-white">¡Acceso Concedido!</h4>
                    <p className="text-xs text-zinc-300 font-medium max-w-sm mx-auto">
                      Tu proceso de desapego de 72 horas ha sido activado de manera prioritaria para <span className="font-bold text-white">{email}</span>.
                    </p>
                  </div>

                  {/* Success Checklist */}
                  <div className="bg-black/30 p-5 rounded-2xl border border-white/10 text-left space-y-3.5 text-xs max-w-sm mx-auto">
                    <div className="flex items-start gap-2.5">
                      <div className="w-4.5 h-4.5 rounded-full bg-emerald-950/40 text-emerald-400 flex items-center justify-center font-bold text-[10px] flex-shrink-0 mt-0.5">✓</div>
                      <div>
                        <strong className="text-white block">Acceso al Protocolo 72H</strong>
                        <p className="text-[10px] text-zinc-400">Enviado un enlace de acceso web y credenciales.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <div className="w-4.5 h-4.5 rounded-full bg-emerald-950/40 text-emerald-400 flex items-center justify-center font-bold text-[10px] flex-shrink-0 mt-0.5">✓</div>
                      <div>
                        <strong className="text-white block">3x Bonos Descargables Liberados</strong>
                        <p className="text-[10px] text-zinc-400">Ritual, Guión de Emergencia y Test.</p>
                      </div>
                    </div>
                  </div>

                  {/* Instant manual downloads as premium feel */}
                  <div className="pt-2">
                    <p className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest mb-3 flex items-center justify-center gap-1.5">
                      <Sparkles size={11} className="text-amber-500" />
                      Descarga Directa Inmediata
                    </p>
                    <div className="space-y-2 max-w-sm mx-auto">
                      <a
                        href="#"
                        onClick={(e) => e.preventDefault()}
                        className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10 hover:border-brand-red hover:bg-white/10 text-xs font-semibold text-zinc-300 hover:text-white transition-all shadow-sm"
                      >
                        <span className="flex items-center gap-2">
                          <FileText size={15} className="text-brand-red" />
                          Protocolo_Desapego_Express_72H.pdf
                        </span>
                        <Download size={13} className="text-zinc-400" />
                      </a>
                      <a
                        href="#"
                        onClick={(e) => e.preventDefault()}
                        className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10 hover:border-brand-red hover:bg-white/10 text-xs font-semibold text-zinc-300 hover:text-white transition-all shadow-sm"
                      >
                        <span className="flex items-center gap-2">
                          <FileText size={15} className="text-emerald-400" />
                          Bono_Mega_AntiRecaidas.pdf
                        </span>
                        <Download size={13} className="text-zinc-400" />
                      </a>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/5">
                    <button
                      onClick={onClose}
                      className="px-6 py-2.5 rounded bg-white text-black hover:bg-brand-red hover:text-black text-xs font-bold transition-all cursor-pointer uppercase tracking-wider"
                    >
                      Entendido, Comprobar mi correo
                    </button>
                    <p className="text-[10px] text-zinc-400 mt-2">¿Problemas para acceder? Escríbenos a soporte@desapego72h.com</p>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
