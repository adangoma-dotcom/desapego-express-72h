import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, HelpCircle } from "lucide-react";
import { FaqItem } from "../types";

const faqItems: FaqItem[] = [
  {
    question: "¿Esto sirve si todavía amo a mi ex?",
    answer: "Sí. De hecho, fue creado específicamente para personas que todavía tienen sentimientos profundos y quieren recuperar el control emocional sin necesidad de negar o enterrar ficticiamente lo que sienten."
  },
  {
    question: "¿Necesito eliminar a mi ex de todas partes?",
    answer: "No necesariamente. El error común es forzar acciones externas sin haber trabajado la raíz del apego interno. Primero necesitas recuperar claridad mental y reducir la carga obsesiva; a partir de ahí, las decisiones externas (como bloquear o no) se toman con tranquilidad y firmeza, no desde la impulsividad."
  },
  {
    question: "¿Cuánto tiempo toma aplicar el método?",
    answer: "El protocolo principal y la secuencia de choque mental están meticulosamente cronometrados para un periodo de 72 horas (3 días). No obstante, la gran mayoría de las personas reportan un alivio significativo de la angustia y menor rumiación mental desde el primer bloque de ejercicios."
  },
  {
    question: "¿Y si la ruptura ocurrió hace meses o años?",
    answer: "Funciona exactamente de la misma manera. El dolor crónico de una ruptura no se mide por cuánto tiempo real ha transcurrido, sino por cuánto apego emocional sigue activo y rumiando en tus pensamientos diarios. Si sigues estancado emocionalmente, este protocolo de choque apagará la señal de apego."
  },
  {
    question: "¿Qué pasa si recaigo?",
    answer: "Precisamente para mitigar esto incluimos de forma prioritaria el Plan de Emergencia Anti-Recaídas. Cuando la nostalgia o la vulnerabilidad ataquen a mitad de la noche, tendrás pautas mecánicas y guiones exactos que seguir para blindar tu mente sin tener que volver a iniciar de cero."
  }
];

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleIndex = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-3">
      {faqItems.map((item, idx) => {
        const isOpen = openIndex === idx;
        return (
          <div
            key={idx}
            className="border border-white/10 bg-white/5 hover:bg-white/10 rounded-xl overflow-hidden transition-all duration-200 shadow-xl"
          >
            <button
              onClick={() => toggleIndex(idx)}
              className="w-full flex items-start justify-between p-5 text-left gap-4 font-semibold text-white/90 hover:text-white transition-colors cursor-pointer"
              aria-expanded={isOpen}
            >
              <span className="text-[15px] md:text-base leading-snug flex items-center gap-2.5">
                <HelpCircle size={16} className="text-zinc-500 flex-shrink-0 mt-0.5" />
                {item.question}
              </span>
              <span className={`flex-shrink-0 mt-1 p-0.5 rounded-full bg-white/5 text-zinc-400 transition-transform duration-300 ${isOpen ? "rotate-180 bg-white/15 text-white" : ""}`}>
                <ChevronDown size={16} />
              </span>
            </button>

            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: "easeInOut" }}
                >
                  <div className="px-5 pb-5 pt-1 text-xs md:text-[13px] text-zinc-300 leading-relaxed max-w-2xl font-normal">
                    {item.answer}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
