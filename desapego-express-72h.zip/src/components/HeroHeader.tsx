import { Sparkles } from "lucide-react";

export default function HeroHeader() {
  return (
    <header className="border-b border-white/10 bg-black/40 py-16 md:py-24 relative overflow-hidden">
      {/* Decorative faint grid bg */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:14px_24px]" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-brand-red/5 rounded-full blur-3xl pointer-events-none" />
      
      <div className="max-w-4xl mx-auto px-4 text-center relative z-10 space-y-6">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-zinc-400 uppercase tracking-[0.25em] bg-white/5 border border-white/10 px-4 py-1.5 rounded-full">
          <Sparkles size={12} className="text-brand-red" />
          <span>Guía Temprana de Liberación</span>
        </div>

        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-black text-white tracking-tight leading-none uppercase">
          DESAPEGO EXPRESS <br className="hidden md:inline" />
          <span className="text-brand-red font-normal italic lowercase font-serif">72h</span>
        </h1>

        <div className="mx-auto w-12 h-[1px] bg-white/10 my-4" />

        <h2 className="font-serif text-3xl md:text-5xl lg:text-6xl text-white max-w-3xl mx-auto font-bold leading-tight tracking-tight">
          EL VERDADERO INFIERNO NO ES QUE TE HAYAN DEJADO
        </h2>

        <p className="font-serif text-xl md:text-2xl text-brand-red max-w-2xl mx-auto italic font-medium leading-relaxed">
          Es seguir viviendo para alguien que ya no forma parte de tu vida.
        </p>

        {/* PRODUCT MOCKUP IMAGE FROM GOOGLE DRIVE */}
        <div className="mx-auto max-w-xs md:max-w-sm mt-10 relative group">
          <div className="absolute inset-0 bg-brand-red/15 rounded-sm blur-2xl group-hover:bg-brand-red/25 transition-all duration-300" />
          <div className="relative border border-white/10 bg-[#0d0d0d] p-3 rounded-sm shadow-2xl transition-transform duration-300 group-hover:scale-[1.01]">
            <img 
              src="https://lh3.googleusercontent.com/d/1dAIxxeejMSRg2Xn_-4r3ZG_xQ7aOGh2e" 
              alt="Desapego Express 72H - Portada Oficial" 
              className="w-full h-auto object-cover rounded-sm border border-white/5"
              referrerPolicy="no-referrer"
              loading="lazy"
              onError={(e) => {
                e.currentTarget.src = "https://drive.google.com/thumbnail?id=1dAIxxeejMSRg2Xn_-4r3ZG_xQ7aOGh2e&sz=w800";
              }}
            />
          </div>
        </div>
      </div>
    </header>
  );
}
