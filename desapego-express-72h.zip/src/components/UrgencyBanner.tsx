import { useState, useEffect } from "react";
import { Clock } from "lucide-react";

interface UrgencyBannerProps {
  onOpenCheckout: () => void;
}

export default function UrgencyBanner({ onOpenCheckout }: UrgencyBannerProps) {
  const [timeLeft, setTimeLeft] = useState(14 * 60 + 35); // Initial countdown: 14 mins, 35 secs

  // Simple countdown simulator
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 14 * 60 + 35));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Format countdown
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="bg-brand-charcoal text-white text-[11px] md:text-xs py-2.5 px-4 sticky top-0 z-50 shadow-xl border-b border-white/10 backdrop-blur-md bg-black/80">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
        <div className="flex items-center gap-1.5 text-center sm:text-left">
          <span className="w-2 h-2 rounded-full bg-brand-red animate-pulse flex-shrink-0" />
          <span className="font-semibold text-white/90 uppercase tracking-wider">OFERTA DE BIENVENIDA ACTIVA:</span>
          <span className="text-zinc-400">Consigue el método completo con un 87% de descuento único</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 font-mono text-amber-300 bg-white/5 py-0.5 px-2 rounded-sm font-semibold">
            <Clock size={12} className="text-amber-400" />
            <span>Cierre del cupón en {formatTime(timeLeft)}</span>
          </div>
          <button
            onClick={onOpenCheckout}
            className="text-[10px] uppercase tracking-widest bg-brand-red hover:bg-white text-black px-4 py-1.5 rounded-sm font-black transition-all hover:scale-[1.02] cursor-pointer shadow-md shadow-brand-red/20"
          >
            Comenzar
          </button>
        </div>
      </div>
    </div>
  );
}
