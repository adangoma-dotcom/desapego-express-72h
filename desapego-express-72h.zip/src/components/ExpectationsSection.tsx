export default function ExpectationsSection() {
  return (
    <section className="py-20 md:py-28 bg-[#0a0a0a] border-b border-white/10">
      <div className="max-w-4xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-4">
          <span className="font-mono text-xs font-bold text-zinc-500 uppercase tracking-widest block font-sans">RESULTADOS ESTIMADOS</span>
          <h2 className="font-serif text-4.5xl md:text-6xl font-black text-white uppercase tracking-tight">
            ¿QUÉ PUEDES ESPERAR?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white/5 p-6 rounded-sm border border-white/10 shadow-sm space-y-3 hover:border-brand-red/30 transition-all">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center font-bold text-[#f97316]">
              1
            </div>
            <h3 className="font-serif text-xl font-bold text-white">Menos pensamientos obsesivos</h3>
            <p className="text-zinc-300 text-xs leading-relaxed font-normal">
              Dejarás de revivir constantemente la relación y recuperarás espacio mental para enfocarte en ti y en tu futuro.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white/5 p-6 rounded-sm border border-white/10 shadow-sm space-y-3 hover:border-brand-red/30 transition-all">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center font-bold text-[#f97316]">
              2
            </div>
            <h3 className="font-serif text-xl font-bold text-white">Más estabilidad emocional</h3>
            <p className="text-zinc-300 text-xs leading-relaxed font-normal">
              Aprenderás a gestionar la tristeza, la ansiedad y la incertidumbre sin depender de la atención de otra persona.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white/5 p-6 rounded-sm border border-white/10 shadow-sm space-y-3 hover:border-brand-red/30 transition-all">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center font-bold text-[#f97316]">
              3
            </div>
            <h3 className="font-serif text-xl font-bold text-white">Recuperar tu identidad</h3>
            <p className="text-zinc-300 text-xs leading-relaxed font-normal">
              Volverás a tomar decisiones pensando en lo que tú quieres y no en lo que perdiste.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
