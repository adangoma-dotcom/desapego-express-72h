export default function BonusesSection() {
  return (
    <section className="py-20 md:py-28 bg-[#0d0d0d] text-zinc-300 relative border-b border-white/10">
      <div className="max-w-4xl mx-auto px-4 space-y-12 relative z-10">
        <div className="text-center space-y-4">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm text-[10px] font-bold bg-amber-400/20 border border-amber-400/30 text-amber-300 uppercase tracking-wider">
            Aceleradores de Recuperación
          </span>
          <h2 className="font-serif text-[38px] md:text-6xl font-black text-white uppercase tracking-tight">
            BONOS EXCLUSIVOS
          </h2>
          <p className="text-zinc-400 text-xs md:text-sm max-w-xl mx-auto font-sans">
            Herramientas adicionales diseñadas para blindar tu proceso mental y acelerar los efectos benéficos del protocolo durante los picos de mayor ansiedad.
          </p>
        </div>

        {/* Bonuses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Bono 1 */}
          <div className="bg-white/5 border border-white/10 rounded-sm p-6 relative overflow-hidden flex flex-col justify-between hover:border-brand-red/40 transition-colors">
            <div className="space-y-4">
              <span className="font-mono text-[9px] bg-amber-400/15 border border-amber-400/20 text-amber-400 px-2 py-0.5 rounded font-bold uppercase tracking-wider inline-block">
                CON ACCESO HOY
              </span>
              <p className="font-serif text-xl font-bold text-brand-red">Bono #1</p>
              <h3 className="font-serif text-lg font-bold text-white leading-tight">Ritual de Liberación Emocional</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-normal">
                La mayoría intenta olvidar. Pero olvidar no funciona cuando el apego sigue activo. Este ejercicio te ayudará a cerrar ciclos pendientes y reducir la carga emocional que todavía te mantiene conectado al pasado.
              </p>
            </div>
            <div className="pt-4 border-t border-white/5 mt-6 text-[10px] text-zinc-400 font-mono flex justify-between items-center">
              <span>VALORADO EN: <del className="text-zinc-600 font-bold">$47</del></span>
              <span className="text-emerald-400 font-semibold font-bold">GRATIS</span>
            </div>
          </div>

          {/* Bono 2 */}
          <div className="bg-white/5 border border-white/10 rounded-sm p-6 relative overflow-hidden flex flex-col justify-between hover:border-brand-red/40 transition-colors">
            <div className="space-y-4">
              <span className="font-mono text-[9px] bg-amber-400/15 border border-amber-400/20 text-amber-400 px-2 py-0.5 rounded font-bold uppercase tracking-wider inline-block">
                CON ACCESO HOY
              </span>
              <p className="font-serif text-xl font-bold text-brand-red">Bono #2</p>
              <h3 className="font-serif text-lg font-bold text-white leading-tight">Guión Anti-Recaídas</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-normal">
                Los momentos más difíciles no ocurren cuando te sientes fuerte. Ocurren cuando estás solo, vulnerable o nostálgico. Este protocolo te muestra exactamente qué hacer para evitar decisiones impulsivas que terminan prolongando el dolor.
              </p>
            </div>
            <div className="pt-4 border-t border-white/5 mt-6 text-[10px] text-zinc-400 font-mono flex justify-between items-center">
              <span>VALORADO EN: <del className="text-zinc-600 font-bold">$47</del></span>
              <span className="text-emerald-400 font-semibold font-bold">GRATIS</span>
            </div>
          </div>

          {/* Bono 3 */}
          <div className="bg-white/5 border border-white/10 rounded-sm p-6 relative overflow-hidden flex flex-col justify-between hover:border-brand-red/40 transition-colors">
            <div className="space-y-4">
              <span className="font-mono text-[9px] bg-amber-400/15 border border-amber-400/20 text-amber-400 px-2 py-0.5 rounded font-bold uppercase tracking-wider inline-block">
                CON ACCESO HOY
              </span>
              <p className="font-serif text-xl font-bold text-brand-red">Bono #3</p>
              <h3 className="font-serif text-lg font-bold text-white leading-tight">Test de Realidad</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-normal">
                Después de una ruptura, la mente suele aferrarse a posibilidades imaginarias. Este ejercicio te ayudará a distinguir entre esperanza y realidad para tomar decisiones desde la claridad y no desde la necesidad emocional.
              </p>
            </div>
            <div className="pt-4 border-t border-white/5 mt-6 text-[10px] text-zinc-400 font-mono flex justify-between items-center">
              <span>VALORADO EN: <del className="text-zinc-600 font-bold">$37</del></span>
              <span className="text-emerald-400 font-semibold font-bold">GRATIS</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
