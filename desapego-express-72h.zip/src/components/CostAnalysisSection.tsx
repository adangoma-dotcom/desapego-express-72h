export default function CostAnalysisSection() {
  return (
    <section className="py-20 md:py-28 bg-[#0a0a0a] border-b border-white/10">
      <div className="max-w-4xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-4">
          <span className="font-mono text-xs font-bold text-zinc-500 uppercase tracking-widest block">ANÁLISIS DE COSTES</span>
          <h2 className="font-serif text-4.5xl md:text-6xl font-black text-white tracking-tight uppercase">
            HAZ CUENTAS...
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 items-stretch">
          
          {/* Option 1 */}
          <div className="bg-white/5 border border-white/10 rounded-sm p-6 flex flex-col justify-between min-h-[250px] hover:border-brand-red/30 transition-all">
            <div className="space-y-2">
              <h3 className="font-bold text-white text-sm uppercase tracking-wide">Terapia Especializada</h3>
              <div className="text-2xl font-mono text-[#f97316] font-bold">
                $80 - $200 <span className="text-xs text-zinc-400">/sesión</span>
              </div>
              <p className="text-[11px] text-zinc-300 leading-normal">
                Una sola sesión de exploración. El avance depende de semanas o meses de asistencia y conversación libre.
              </p>
            </div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-6">ALTO COSTE INICIAL</span>
          </div>

          {/* Option 2 */}
          <div className="bg-white/5 border border-white/10 rounded-sm p-6 flex flex-col justify-between min-h-[250px] hover:border-brand-red/30 transition-all">
            <div className="space-y-2">
              <h3 className="font-bold text-white text-sm uppercase tracking-wide">Tratamiento Completo</h3>
              <div className="text-2xl font-mono text-[#f97316] font-bold">$2,000 - $3,000</div>
              <p className="text-[11px] text-zinc-300 leading-normal">
                Acompañamiento individual a largo plazo. Excelente pero restrictivo económicamente para la gran mayoría de personas.
              </p>
            </div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-6">INVERSIÓN CRÍTICA</span>
          </div>

          {/* Option 3 - Highlighting Desapego Express */}
          <div className="bg-black/55 text-white rounded-sm p-6 border-2 border-brand-red flex flex-col justify-between relative overflow-hidden min-h-[250px] shadow-lg">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-red opacity-10 rounded-full blur-xl animate-pulse" />
            <div className="space-y-2 relative z-10">
              <span className="inline-block text-[9px] px-2 py-0.5 rounded-sm bg-brand-red text-white font-bold uppercase tracking-wider mb-1">PROGRAMA COMPLETO</span>
              <h3 className="font-bold text-white text-sm uppercase tracking-wide">Desapego Express 72H</h3>
              <div className="text-3xl font-mono text-amber-300 font-black">$27.00 <span className="text-xs text-zinc-400 font-normal">/pago único</span></div>
              <p className="text-[11px] text-zinc-300 leading-normal font-normal">
                Un sistema mecánico claro, práctico y diseñado específicamente para ayudarte a recuperar tu estabilidad emocional de inmediato desde hoy.
              </p>
            </div>
            <span className="text-[10px] text-amber-300 font-bold uppercase tracking-widest mt-4">87% DE AHORRO CONCEDIDO</span>
          </div>

        </div>

        <p className="text-center text-xs md:text-sm text-zinc-400 max-w-xl mx-auto pt-4 leading-normal">
          Y aun así, nadie puede hacer el trabajo interno por ti. La diferencia es que aquí tendrás un sistema claro, práctico y diseñado específicamente para ayudarte a recuperar estabilidad emocional después de una ruptura.
        </p>
      </div>
    </section>
  );
}
