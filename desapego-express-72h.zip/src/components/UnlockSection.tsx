import { Brain, Users, ShieldAlert, Flame, Target } from "lucide-react";

export default function UnlockSection() {
  return (
    <section className="bg-[#0a0a0a] text-[#d4d4d4] py-20 md:py-28 relative border-b border-white/5">
      {/* Subtle grid layer */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:14px_24px]" />
      
      <div className="max-w-4xl mx-auto px-4 relative z-10 space-y-12">
        <div className="text-center space-y-4">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-brand-red/20 border border-brand-red/30 text-brand-red uppercase tracking-wider">
            Módulos del Sistema
          </span>
          <h2 className="font-serif text-4.5xl md:text-6xl font-black tracking-tight text-white uppercase">
            ¿QUÉ DESBLOQUEARÁS?
          </h2>
          <p className="text-zinc-400 text-xs md:text-sm max-w-xl mx-auto font-sans">
            Un protocolo cronometrado paso a paso diseñado mecánicamente para forzar el reinicio emocional y desvincular el apego involuntario.
          </p>
        </div>

        {/* Checklist Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          
          {/* Card 1 */}
          <div className="bg-[#0d0d0d] border border-white/10 rounded-sm p-6 space-y-3 shadow-lg hover:border-brand-red/50 transition-colors group">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center text-brand-red group-hover:bg-brand-red/20 transition-all">
              <Brain size={18} />
            </div>
            <h3 className="font-serif text-xl font-bold text-white tracking-tight">✓ Protocolo de Corte Mental 72H</h3>
            <p className="text-zinc-400 text-xs leading-relaxed">
              Un proceso guiado para interrumpir el ciclo de pensamientos obsesivos y recuperar claridad mental sin depender del tiempo para sentirte mejor.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-[#0d0d0d] border border-white/10 rounded-sm p-6 space-y-3 shadow-lg hover:border-brand-red/50 transition-colors group">
            <div className="w-10 h-10 rounded-sm bg-white/5 border border-white/10 flex items-center justify-center text-zinc-300 group-hover:bg-zinc-800 transition-all">
              <Target size={18} />
            </div>
            <h3 className="font-serif text-xl font-bold text-white tracking-tight">✓ Método Anti-Idealización</h3>
            <p className="text-zinc-400 text-xs leading-relaxed">
              Aprenderás a separar la realidad de la fantasía para dejar de ver a tu ex como la única persona capaz de hacerte feliz.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-[#0d0d0d] border border-white/10 rounded-sm p-6 space-y-3 shadow-lg hover:border-brand-red/50 transition-colors group">
            <div className="w-10 h-10 rounded-sm bg-white/5 border border-white/10 flex items-center justify-center text-zinc-300 group-hover:bg-zinc-800 transition-all">
              <Users size={18} />
            </div>
            <h3 className="font-serif text-xl font-bold text-white tracking-tight">✓ Sistema de Recuperación de Identidad</h3>
            <p className="text-zinc-400 text-xs leading-relaxed">
              Reconstruye la relación más importante de tu vida: la que tienes contigo mismo. Recupera seguridad, dirección y propósito.
            </p>
          </div>

          {/* Card 4 */}
          <div className="bg-[#0d0d0d] border border-white/10 rounded-sm p-6 space-y-3 shadow-lg hover:border-brand-red/50 transition-colors group">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center text-brand-red group-hover:bg-brand-red/20 transition-all">
              <ShieldAlert size={18} />
            </div>
            <h3 className="font-serif text-xl font-bold text-white tracking-tight">✓ Plan de Emergencia Anti-Recaídas</h3>
            <p className="text-zinc-400 text-xs leading-relaxed">
              Sabrás exactamente qué hacer cuando aparezcan las ganas de escribir, revisar redes o buscar cualquier excusa para volver a contactar.
            </p>
          </div>

          {/* Card 5 - Span full on large screens */}
          <div className="bg-[#0d0d0d] border border-white/10 rounded-sm p-6 space-y-3 shadow-lg hover:border-brand-red/50 transition-colors group md:col-span-2">
            <div className="w-10 h-10 rounded-sm bg-brand-red/10 border border-brand-red/20 flex items-center justify-center text-brand-red group-hover:bg-brand-red/20 transition-all">
              <Flame size={18} />
            </div>
            <h3 className="font-serif text-xl font-bold text-white tracking-tight">✓ Reinicio Emocional de 3 Días</h3>
            <p className="text-zinc-400 text-xs leading-relaxed max-w-2xl">
              Una secuencia práctica diseñada para ayudarte a dejar de sobrevivir la ruptura y empezar a reconstruir tu vida.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
