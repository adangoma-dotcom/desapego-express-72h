export default function ValueProposalSection() {
  return (
    <section className="py-20 md:py-28 bg-[#0d0d0d] border-b border-white/10">
      <div className="max-w-4xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center">
        
        <div className="space-y-6">
          <span className="font-mono text-xs font-bold text-zinc-500 block uppercase tracking-widest">PROPUESTA DE VALOR</span>
          <h2 className="font-serif text-3.5xl md:text-5.5xl font-black text-white tracking-tight leading-none uppercase">
            LO QUE REALMENTE <br className="hidden md:inline" /> ESTÁS COMPRANDO
          </h2>
          <p className="text-zinc-300 text-sm md:text-base">
            No estás comprando información. Información ya tienes suficiente.
          </p>
          
          <div className="space-y-3.5 text-xs text-zinc-400 font-normal pl-3">
            <div className="flex items-start gap-2">
              <span className="text-brand-red font-bold mt-0.5">•</span>
              <span>Has visto de todo tipo de videos en TikTok e Instagram.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-brand-red font-bold mt-0.5">•</span>
              <span>Has leído frases inspiradoras y guardado posts tristes.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-brand-red font-bold mt-0.5">•</span>
              <span>Has escuchado consejos repetidos de amigos y familiares.</span>
            </div>
          </div>

          <div className="p-4 bg-white/5 border border-white/10 text-white text-xs md:text-sm font-semibold max-w-sm rounded-sm">
            Y aun así... sigues sintiéndote exactamente igual.
          </div>
        </div>

        {/* Process / Pathway Box visualization */}
        <div className="bg-black/40 text-white p-8 border border-white/10 shadow-2xl relative overflow-hidden space-y-6 rounded-sm">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-red opacity-15 rounded-full blur-2xl" />
          <p className="font-mono text-[10px] uppercase font-bold text-amber-300 tracking-widest bg-white/5 py-1 px-3 rounded-full inline-block">El Verdadero Atajo</p>
          
          <h3 className="font-serif text-2xl md:text-3.5xl font-bold leading-tight">
            Lo que estás comprando es un proceso. Una estructura.
          </h3>
          
          <p className="text-zinc-300 text-xs md:text-[13px] leading-relaxed">
            Un camino claro y sin rodeos empíricos para recuperar tu estabilidad emocional y volver a sentir de inmediato que tu vida te pertenece.
          </p>

          <div className="divide-y divide-zinc-800 text-xs text-white/80">
            <div className="py-3 flex items-center justify-between">
              <span>Punto A: Parálisis y obsesión</span>
              <span className="text-brand-red font-bold font-mono">Antes</span>
            </div>
            <div className="py-3 flex items-center justify-between">
              <span>Secuencia de 72H de Choque Emocional</span>
              <span className="text-amber-400 font-semibold">Proceso</span>
            </div>
            <div className="py-3 flex items-center justify-between">
              <span>Punto B: Soberanía y paz mental</span>
              <span className="text-emerald-400 font-bold font-mono">Después</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
