import { Shield } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#0a0a0a] text-zinc-500 py-12 border-t border-white/5 text-xs font-normal">
      <div className="max-w-6xl mx-auto px-4 space-y-6 text-center">
        <div className="flex flex-wrap items-center justify-center gap-6 text-[11px] text-zinc-400">
          <span className="font-mono text-zinc-500 uppercase tracking-widest font-bold">DESAPEGO EXPRESS 72H</span>
          <span className="hidden md:inline text-zinc-800">|</span>
          <a href="#" className="hover:text-white transition-colors" onClick={(e) => e.preventDefault()}>Términos de Servicio</a>
          <span className="text-zinc-800">•</span>
          <a href="#" className="hover:text-white transition-colors" onClick={(e) => e.preventDefault()}>Políticas de Privacidad</a>
          <span className="text-zinc-800">•</span>
          <a href="#" className="hover:text-white transition-colors" onClick={(e) => e.preventDefault()}>Contacto de Soporte</a>
        </div>

        <div className="max-w-2xl mx-auto text-[10px] text-zinc-600 space-y-2.5 leading-relaxed">
          <p>
            © {new Date().getFullYear()} Desapego Express 72H. Todos los derechos reservados.
          </p>
          <p>
            Descargo de responsabilidad: Desapego Express es un protocolo psicológico de autoayuda y educación emocional orientativo. No sustituye la consulta personalizada de un profesional médico o psiquiatra idóneo para procesos de salud mental crónicos. Los resultados varían según la implementación voluntaria del programa.
          </p>
          <p className="pt-2 text-zinc-600 text-[9px] uppercase tracking-wider flex items-center justify-center gap-1.5 font-mono">
            <Shield size={11} /> Seguridad Verificada SSL por AI Studio Secure Sandbox
          </p>
        </div>
      </div>
    </footer>
  );
}
