export interface Question {
  id: string;
  text: string;
  category: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface BonusItem {
  id: string;
  badge: string;
  title: string;
  description: string;
  iconName: string;
}

export interface Milestone {
  hours: string;
  title: string;
  description: string;
  iconName: string;
}
